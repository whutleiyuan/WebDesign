;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-next-s" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M512 862.98584c-193.530738 0-350.98584-157.455101-350.98584-350.98584s157.455101-350.98584 350.98584-350.98584 350.98584 157.455101 350.98584 350.98584S705.530738 862.98584 512 862.98584zM512 204.88739c-169.344896 0-307.11261 137.767713-307.11261 307.11261s137.767713 307.11261 307.11261 307.11261 307.11261-137.767713 307.11261-307.11261S681.344896 204.88739 512 204.88739z"  ></path>' +
    '' +
    '<path d="M460.811154 689.967274c-5.612834 0-11.225669-2.142803-15.510252-6.426363-8.569166-8.569166-8.569166-22.450315 0-31.019481L567.837726 529.983583c8.547677-8.547677 8.547677-22.471804 0-31.019481L445.300902 376.427278c-8.569166-8.569166-8.569166-22.450315 0-31.019481 8.569166-8.569166 22.450315-8.569166 31.019481 0l122.536824 122.536824c25.664519 25.653263 25.664519 67.406203 0 93.059466L476.320383 683.539888C472.0358 687.824471 466.423989 689.967274 460.811154 689.967274z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-data" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M540.121478 62.036915l-56.242955 0c-31.064506 0-56.246025 25.178449-56.246025 56.239885l0 787.445376c0 31.061436 25.181519 56.239885 56.246025 56.239885l56.242955 0c31.064506 0 56.246025-25.178449 56.246025-56.239885L596.367503 118.2768C596.36648 87.215364 571.185984 62.036915 540.121478 62.036915zM540.121478 877.593536c0 15.534811-12.590759 28.128641-28.120454 28.128641-15.534811 0-28.122501-12.593829-28.122501-28.128641L483.878522 146.400325c0-15.529695 12.58769-28.122501 28.122501-28.122501 15.529695 0 28.120454 12.593829 28.120454 28.122501L540.121478 877.593536z"  ></path>' +
    '' +
    '<path d="M258.892375 315.140447l-56.242955 0c-31.064506 0-56.246025 25.181519-56.246025 56.246025l0 534.336728c0 31.061436 25.181519 56.239885 56.246025 56.239885l56.242955 0c31.064506 0 56.246025-25.178449 56.246025-56.239885L315.1384 371.385449C315.1384 340.320942 289.956881 315.140447 258.892375 315.140447zM258.892375 877.593536c0 15.534811-12.590759 28.128641-28.120454 28.128641-15.534811 0-28.122501-12.593829-28.122501-28.128641l0-478.088656c0-15.526625 12.58769-28.120454 28.122501-28.120454 15.529695 0 28.120454 12.593829 28.120454 28.120454L258.892375 877.593536z"  ></path>' +
    '' +
    '<path d="M821.349557 512l-56.246025 0c-31.064506 0-56.246025 25.183566-56.246025 56.242955l0 337.479221c0 31.061436 25.181519 56.239885 56.246025 56.239885l56.246025 0c31.064506 0 56.246025-25.178449 56.246025-56.239885L877.595582 568.242955C877.595582 537.183566 852.414063 512 821.349557 512zM821.349557 877.593536c0 15.534811-12.590759 28.128641-28.120454 28.128641-15.534811 0-28.125571-12.593829-28.125571-28.128641L765.103532 596.365456c0-15.523555 12.590759-28.122501 28.125571-28.122501 15.529695 0 28.120454 12.598946 28.120454 28.122501L821.349557 877.593536z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M406.869333 476.842667c0-6.144 2.730667-11.946667 7.509333-16.384 8.874667-7.509333 22.186667-6.144 29.696 2.730667l65.536 79.189333 70.997333-79.872c7.850667-8.533333 21.162667-9.557333 29.696-1.706667 8.533333 7.850667 9.557333 21.162667 1.706667 29.696l-77.824 87.722667c-6.485333 7.509333-15.701333 11.605333-25.258667 11.264-9.557333 0-18.773333-4.778667-24.917333-12.288l-72.021333-87.381333C408.234667 486.4 406.869333 481.621333 406.869333 476.842667z"  ></path>' +
    '' +
    '<path d="M154.282667 512c0-197.290667 160.426667-357.717333 357.717333-357.717333s357.717333 160.426667 357.717333 357.717333-160.426667 357.717333-357.717333 357.717333S154.282667 709.290667 154.282667 512zM827.392 512c0-174.08-141.653333-315.392-315.392-315.392S196.608 337.92 196.608 512 337.92 827.392 512 827.392 827.392 686.08 827.392 512z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-wendang" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M897.563 965.484H111.799c-59.921 0-100.088-47.771-100.088-107.687V166.07c0-59.904 40.168-109.601 100.088-109.601H401.9c14.463 0 27.064 9.905 30.448 23.966l32.145 132.761h433.084c59.906 0 117.191 49.696 117.191 109.602v535c-0.001 59.916-57.286 107.687-117.205 107.687M111.799 119.16c-25.343 0-37.396 21.583-37.396 46.908v691.728c0 25.359 12.053 44.993 37.396 44.993h785.777c25.329 0 54.497-19.635 54.497-44.993v-535c0-25.329-29.169-46.911-54.513-46.911H439.812c-14.47 0-27.071-9.905-30.454-23.966l-32.146-132.76H111.798m0.001 0.001z" fill="" ></path>' +
    '' +
    '<path d="M927.845 150.503H536.027c-17.305 0-31.348-14.044-31.348-31.343 0-17.305 14.043-31.348 31.348-31.348h391.818c17.3 0 31.345 14.043 31.345 31.348-0.001 17.299-14.03 31.343-31.345 31.343m0 0z" fill="" ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)